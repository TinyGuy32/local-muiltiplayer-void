http = require("http")
console.log(5347)

function range(string,start,end) {
	FOn1 = start
	result = ""
	while(FOn1<end) {
		result += string[FOn1]
		FOn1 += 1
	}
	return result
}

function isAinB(A,B) {
	FOn2 = 0
	result = false
	while(FOn2<B.length){
		if(B[FOn2] == A){
			result = true
		}
		FOn2 += 1
	}
	return result
}

function readList(list){
	FOn3 = 0
	result = ""
	while(FOn3<list.length) {
		result += list[FOn3]+","
		FOn3 += 1
	}
	return range(result,0,result.length-1)
}

function ALocationInB(A,B) {
	FOn4 = 0
	result = 0
	while(FOn4<B.length) {
		if(A==B[FOn4]) {
			result = FOn4
		}
		FOn4 += 1
	}
	return result
}

playerCordinates = []
playerIps = []

http.createServer(function(req,res) {
	if(isAinB(req.connection.remoteAddress,playerIps)){
		if(req.url!="/favicon.ico"){
			playerCordinates[ALocationInB(req.connection.remoteAddress,playerIps)] = range(req.url,1,req.url.length).split("b")
		}
	}
	else{
		if(req.url!="favicon.ico") {
			playerIps.push(req.connection.remoteAddress)
			playerCordinates.push((range(req.url,1,req.url.length).split("b")))
		}
	}
	res.write(readList(playerCordinates))
	res.end()
}).listen(5347)
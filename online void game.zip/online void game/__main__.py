import pygame
import requests

def main():

    playerX = 0
    playerY = 0
    
    width=400
    height=400

    pygame.init()
    pygame.display.set_caption("THE VOID")
    
    screen = pygame.display.set_mode((width,height))

    ip = input("enter the server ip:")

    players = []

    running = True
    while running:
        try:
            players = []
            list1 = requests.get(ip+"/"+str(playerX)+"b"+str(playerY)).text.split(",")
            on = 0
            while on<len(list1)-1:
                players.append([int(list1[on]),int(list1[on+1])])
                on+=2
            print(players)
            print(list1)
            screen.fill((0,0,0))
            for a in players:
                npcX = a[0]
                npcY = a[1]
                if (npcX+width/2)-playerX>-1 and (npcX+width/2)-playerX<width and (npcY+height/2)-playerY>-1 and (npcY+height/2)-playerY<height:
                    screen.blit(pygame.image.load("images\\player.png"),((npcX+width/2)-playerX,(npcY+height/2)-playerY))
            screen.blit(pygame.image.load("images\\you.png"),(width/2,height/2))
            pygame.display.flip()
            for event in pygame.event.get():
                if event.type==pygame.KEYDOWN:
                    if event.key == pygame.K_d:
                        playerX += 10
                        print(playerX)
                    if event.key == pygame.K_a:
                        playerX -= 10
                        print(playerX)
                    if event.key == pygame.K_w:
                        playerY -= 10
                        print(playerY)
                    if event.key == pygame.K_s:
                        playerY += 10
                        print(playerY)
                    if event.type==pygame.QUIT:
                        running = False
        except:
            print(requests.get("http://www.google.com"))
if __name__=="__main__":
    main()
